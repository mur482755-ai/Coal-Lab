.model small
.stack 100h

.data
name db "Full Name: Tayyaba Kanwal $"
sap db 0Dh,0Ah,"SAP ID: 68719 $"
batch db 0Dh,0Ah,"Batch: 2025 Spring $"
program db 0Dh,0Ah,"Program + Semester: BSSE 3rd Semester $"

.code
main proc
    mov ax, @data
    mov ds, ax

    mov ah, 09h
    mov dx, offset name
    int 21h

    mov dx, offset sap
    int 21h

    mov dx, offset batch
    int 21h

    mov dx, offset program
    int 21h

    mov ah, 4ch
    int 21h

main endp
end main