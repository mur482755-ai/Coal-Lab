
.model small
.data
msg DB "Cube $"

.code
main proc

mov ax, @data
mov ds, ax

mov al,3
mov bl,al
mul bl

mov bl,3
mul bl

mov dx, offset msg
mov ah,9
int 21h

mov dl,al
add dl,48
mov ah,2
int 21h

mov ah,4ch
int 21h

main endp
end main